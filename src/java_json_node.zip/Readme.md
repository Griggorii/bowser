                                                       OS19 19.04

Добыто и нагенерировано с помощью смешанной операционной системы OS19 19.04 2.0 

https://github.com/Griggorii/Cinnamon-Budgie-Linux-OS-20-based-20.10-Ubuntu-Groovy-Gorilla

#Only real technologies, not any fictional parasitic distributions support real technology investments and donate dollar card VISA 4817 7601 8112 4706

Я не могу заниматься js по скольку занимаюсь dconf настроикой , вы же если взяли заработали и какой то процент отправили на карту как благодарность и так далее. Будут деньги восстановим феникс из пепла OS19 
