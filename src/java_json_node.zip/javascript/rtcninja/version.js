'use strict';

// Expose the 'version' field of package.json.
module.exports = require('../package.json').version;

